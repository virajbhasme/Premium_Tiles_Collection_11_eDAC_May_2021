import {
  CART_CUSTOMIZED_ACCEPT_FAIL,
  CART_CUSTOMIZED_ACCEPT_REQUEST,
  CART_CUSTOMIZED_ACCEPT_SUCCESS,
  CART_CUSTOMIZED_FAIL,
  CART_CUSTOMIZED_REQUEST,
  CART_CUSTOMIZED_SUCCESS,
  CART_DELIVER_FAIL,
  CART_DELIVER_REQUEST,
  CART_DELIVER_SUCCESS,
  CART_ORDER_FAIL,
  CART_ORDER_REQUEST,
  CART_ORDER_SUCCESS,
} from '../constants/CartConstants'

export const cartOrderReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_ORDER_REQUEST:
      return { loading: true }
    case CART_ORDER_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_ORDER_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const cartCustomizedReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_CUSTOMIZED_REQUEST:
      return { loading: true }
    case CART_CUSTOMIZED_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_CUSTOMIZED_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const cartDeliverReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_DELIVER_REQUEST:
      return { loading: true }
    case CART_DELIVER_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_DELIVER_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const cartCustomizedAcceptReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_CUSTOMIZED_ACCEPT_REQUEST:
      return { loading: true }
    case CART_CUSTOMIZED_ACCEPT_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_CUSTOMIZED_ACCEPT_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}
