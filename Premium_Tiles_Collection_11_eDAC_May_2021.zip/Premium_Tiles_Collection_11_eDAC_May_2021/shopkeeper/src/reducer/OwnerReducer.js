import {
  OWNER_OTP_FAIL,
  OWNER_OTP_REQUEST,
  OWNER_OTP_SUCCESS,
  OWNER_PASS_RESET_FAIL,
  OWNER_PASS_RESET_REQUEST,
  OWNER_PASS_RESET_SUCCESS,
  OWNER_PROFILE_FAIL,
  OWNER_PROFILE_PIC_FAIL,
  OWNER_PROFILE_PIC_REQUEST,
  OWNER_PROFILE_PIC_SUCCESS,
  OWNER_PROFILE_PIC_UPLOAD_FAIL,
  OWNER_PROFILE_PIC_UPLOAD_REQUEST,
  OWNER_PROFILE_PIC_UPLOAD_SUCCESS,
  OWNER_PROFILE_REQUEST,
  OWNER_PROFILE_SUCCESS,
  OWNER_PROFILE_UPDATE_FAIL,
  OWNER_PROFILE_UPDATE_REQUEST,
  OWNER_PROFILE_UPDATE_SUCCESS,
  OWNER_SIGNIN_FAIL,
  OWNER_SIGNIN_REQUEST,
  OWNER_SIGNIN_SUCCESS,
  OWNER_SIGNUP_FAIL,
  OWNER_SIGNUP_REQUEST,
  OWNER_SIGNUP_SUCCESS,
} from '../constants/ShopKeeperConstants'

export const ownerSignupReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_SIGNUP_REQUEST:
      return { loading: true }
    case OWNER_SIGNUP_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_SIGNUP_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerSignInReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_SIGNIN_REQUEST:
      return { loading: true }
    case OWNER_SIGNIN_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_SIGNIN_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerProfilePicUploadReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_PROFILE_PIC_UPLOAD_REQUEST:
      return { loading: true }
    case OWNER_PROFILE_PIC_UPLOAD_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_PROFILE_PIC_UPLOAD_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerProfileRequestReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_PROFILE_REQUEST:
      return { loading: true }
    case OWNER_PROFILE_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_PROFILE_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerProfilePicRequestReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_PROFILE_PIC_REQUEST:
      return { loading: true }
    case OWNER_PROFILE_PIC_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_PROFILE_PIC_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerProfileUpdateRequestReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_PROFILE_UPDATE_REQUEST:
      return { loading: true }
    case OWNER_PROFILE_UPDATE_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_PROFILE_UPDATE_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerOtpRequestReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_OTP_REQUEST:
      return { loading: true }
    case OWNER_OTP_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_OTP_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const ownerPasswordUpdateReducer = (state = {}, action) => {
  switch (action.type) {
    case OWNER_PASS_RESET_REQUEST:
      return { loading: true }
    case OWNER_PASS_RESET_SUCCESS:
      return { loading: false, response: action.payload }
    case OWNER_PASS_RESET_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}
