import {
  HOME_PRODUCT_FETCH_FAIL,
  HOME_PRODUCT_FETCH_REQUEST,
  HOME_PRODUCT_FETCH_SUCCESS,
} from '../constants/HomeConstants'

export const HomeProductFetchReducer = (state = {}, action) => {
  switch (action.type) {
    case HOME_PRODUCT_FETCH_REQUEST:
      return { loading: true }
    case HOME_PRODUCT_FETCH_SUCCESS:
      return { loading: false, response: action.payload }
    case HOME_PRODUCT_FETCH_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}
