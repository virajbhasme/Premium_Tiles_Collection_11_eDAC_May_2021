import { useEffect, useState } from 'react'
import { Carousel } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { HomeProductFetchFunc } from '../action/HomeAction'
import '../css/home.css'

const HomeScreen = (props) => {
  const [counter, setCounter] = useState(true)
  const [dataFetched, setDataFetched] = useState(false)
  const [data, setData] = useState([])

  const HomeProductFetch = useSelector((store) => store.HomeProductFetch)
  const { response, loading, error } = HomeProductFetch

  const dispatch = useDispatch()

  const onLoad = () => {
    setDataFetched(true)
    dispatch(HomeProductFetchFunc())
  }

  const setDataValues = (values) => {
    let index = 0
    setData(
      values.map((tile) => {
        console.log(tile)
        const byteCharacters = atob(tile.blob)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/*' })
        index++

        return {
          tile: tile.tiles,
          blob,
          index,
        }
      })
    )

    console.log(data)
  }

  const convertSize = (value) => {
    let index = value.indexOf('X')
    let string1 = value.slice(1, index)
    let string2 = value.slice(index + 1)
    return string1 + ' X ' + string2 + ' cm'
  }

  const convertFinishing = (value) => {
    let index = value.indexOf(' ')
    if (index === -1) {
      return value.slice(0, 1) + value.slice(1).toLowerCase()
    } else {
      let result = value.slice(0, 1) + value.slice(1, index).toLowerCase() + ' '
      while (index !== -1) {
        let secondIndex = value.indexOf(' ', index + 1)
        if (secondIndex === -1) {
          result +=
            value.slice(index + 1, index + 2) +
            value.slice(index + 2).toLowerCase()
        } else {
          result +=
            value.slice(index + 1, index + 2) +
            value.slice(index + 2, secondIndex).toLowerCase() +
            ' '
        }
        index = secondIndex
      }
      return result
    }
  }

  useEffect(() => {
    if (counter) {
      onLoad()
      setCounter(false)
    }
    if (response && response.status === 'success' && dataFetched) {
      setDataFetched(false)
      setDataValues(response.data)
      console.log(response.data)
    } else if (response && response.status === 'error' && dataFetched) {
      alert(response.data)
      setDataFetched(false)
    } else if (error && dataFetched) {
      alert(error)
      setDataFetched(false)
    }
  }, [response, loading, error])

  return (
    <div>
      {data.length !== 0 && (
        <div className="homeDiv">
          <Carousel>
            {data.map((tile) => {
              return (
                <Carousel.Item interval={1000} key={tile.index}>
                  <img
                    width="100pc"
                    height="550px"
                    className="d-block w-100"
                    src={URL.createObjectURL(tile.blob)}
                    alt="First slide"
                  />
                  <Carousel.Caption>
                    <h3>{tile.tile.tilesName}</h3>
                    <p>
                      <div>size :: {convertSize(tile.tile.productSize)}</div>
                      <div>
                        finishing ::{' '}
                        {convertFinishing(tile.tile.productFinishing)}
                      </div>
                    </p>
                  </Carousel.Caption>
                </Carousel.Item>
              )
            })}
          </Carousel>
        </div>
      )}
      {data.length === 0 && (
        <div className="text-danger">products are not available</div>
      )}
    </div>
  )
}

export default HomeScreen
