import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import { CartDeliveryFunc, CartOrderFunc } from '../action/CartAction'

const OrderScreen = (props) => {
  const [counter, setCounter] = useState(true)
  const [dataFetched, setDataFetched] = useState(false)
  const [deliverDone, setDeliverDone] = useState(false)
  const [data, setData] = useState([])

  const CartOrders = useSelector((store) => store.CartOrders)
  const { response, loading, error } = CartOrders

  const CartDelivery = useSelector((store) => store.CartDelivery)
  const { loading: loading1, error: error1, response: response1 } = CartDelivery

  const dispatch = useDispatch()

  const onLoad = () => {
    setDataFetched(true)
    dispatch(CartOrderFunc())
  }

  const setDataValues = (values) => {
    let index = 0
    setData(
      values.map((cart) => {
        const byteCharacters = atob(cart.blob)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/*' })
        index++

        return {
          cart: cart.cart,
          blob,
          index,
        }
      })
    )
  }

  const onDeliverCLick = (c) => {
    console.log(c.id)
    if (window.confirm('are u sure')) {
      setDeliverDone(true)
      dispatch(CartDeliveryFunc(c.id))
    }
  }

  useEffect(() => {
    if (counter) {
      onLoad()
      setCounter(false)
    }
    if (response && response.status === 'success' && dataFetched) {
      setDataFetched(false)
      setDataValues(response.data)
      console.log(response.data)
    } else if (response && response.status === 'error' && dataFetched) {
      alert(response.data)
      setDataFetched(false)
    } else if (error && dataFetched) {
      alert(error)
      setDataFetched(false)
    }

    if (response1 && response1.status === 'success' && deliverDone) {
      console.log(response1.data)
      alert(response1.data)
      setDeliverDone(false)
      onLoad()
    } else if (response1 && response1.status === 'error' && deliverDone) {
      console.log(response1)
      setDeliverDone(false)
    } else if (error1 && deliverDone) {
      setDeliverDone(false)
      alert(error1)
    }
  }, [response, loading, error, response1, loading1, error1])
  return (
    <div style={{ width: '1000px', marginTop: '50px', marginLeft: '200px' }}>
      <h3>Orders</h3>
      <table
        style={{ marginTop: '30px' }}
        className="table table-light table-striped">
        <thead>
          <tr>
            <th>sr no</th>
            <th>Tile Name</th>
            <th>User Name</th>
            <th>price</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {data.length !== 0 &&
            data.map((cart) => {
              return (
                <tr key={cart.index}>
                  <td>{cart.index}</td>
                  <td>{cart.cart.tile.tilesName}</td>
                  <td>
                    {cart.cart.user.firstName} {cart.cart.user.lastName}
                  </td>
                  <td>{cart.cart.count * cart.cart.tile.price}</td>
                  <td>
                    <button
                      onClick={() => {
                        onDeliverCLick(cart.cart)
                      }}
                      className="btn btn-outline-dark">
                      deliver
                    </button>
                  </td>
                </tr>
              )
            })}
        </tbody>
      </table>
    </div>
  )
}

export default OrderScreen
