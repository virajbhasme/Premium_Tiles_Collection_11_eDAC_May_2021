import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { CartAcceptFunc, CartCustomizedOrderFunc } from '../action/CartAction'

const CustomOrder = (props) => {
  const [counter, setCounter] = useState(true)
  const [dataFetched, setDataFetched] = useState(false)
  const [acceptDone, setAcceptDone] = useState(false)
  const [data, setData] = useState([])

  const CartCustomizedOrders = useSelector(
    (store) => store.CartCustomizedOrders
  )
  const { response, loading, error } = CartCustomizedOrders

  const CartCustomizedAccept = useSelector(
    (store) => store.CartCustomizedAccept
  )
  const {
    loading: loading1,
    error: error1,
    response: response1,
  } = CartCustomizedAccept

  const dispatch = useDispatch()

  const onLoad = () => {
    setDataFetched(true)
    dispatch(CartCustomizedOrderFunc())
  }

  const setDataValues = (values) => {
    let index = 0
    setData(
      values.map((cart) => {
        const byteCharacters = atob(cart.blob)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/*' })
        index++

        return {
          cart: cart.cart,
          blob,
          index,
        }
      })
    )
  }

  const onAcceptClick = (c) => {
    console.log(c.id)
    if (window.confirm('are u sure')) {
      setAcceptDone(true)
      dispatch(CartAcceptFunc(c.id))
    }
  }

  useEffect(() => {
    if (counter) {
      onLoad()
      setCounter(false)
    }
    if (response && response.status === 'success' && dataFetched) {
      setDataFetched(false)
      setDataValues(response.data)
      console.log(response.data)
    } else if (response && response.status === 'error' && dataFetched) {
      alert(response.data)
      setDataFetched(false)
    } else if (error && dataFetched) {
      alert(error)
      setDataFetched(false)
    }

    if (response1 && response1.status === 'success' && acceptDone) {
      console.log(response1.data)
      alert(response1.data)
      setAcceptDone(false)
      onLoad()
    } else if (response1 && response1.status === 'error' && acceptDone) {
      console.log(response1)
      setAcceptDone(false)
    } else if (error1 && acceptDone) {
      setAcceptDone(false)
      alert(error1)
    }
  }, [response, loading, error, response1, loading1, error1])
  return (
    <div style={{ width: '1000px', marginTop: '50px', marginLeft: '200px' }}>
      <h3>Custom Orders</h3>
      <table
        style={{ marginTop: '30px' }}
        className="table table-light table-striped">
        <thead>
          <tr>
            <th>sr no</th>
            <th>Tile Name</th>
            <th>User Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {data.length !== 0 &&
            data.map((cart) => {
              return (
                <tr key={cart.index}>
                  <td>{cart.index}</td>
                  <td>{cart.cart.tile.tilesName}</td>
                  <td>
                    {cart.cart.user.firstName} {cart.cart.user.lastName}
                  </td>
                  <td>
                    <button
                      onClick={() => {
                        onAcceptClick(cart.cart)
                      }}
                      className="btn btn-outline-primary">
                      accept
                    </button>
                  </td>
                </tr>
              )
            })}
        </tbody>
      </table>
    </div>
  )
}

export default CustomOrder
