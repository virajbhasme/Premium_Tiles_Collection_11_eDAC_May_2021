import { useEffect } from 'react'
import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { TileAddFunc, tilePicUpload } from '../action/TilesAction'
import ProductFinishingList from '../components/AddTilesComponent/ProductFinishingList'
import ProductMaterialList from '../components/AddTilesComponent/ProductMaterialList'
import ProductSizeList from '../components/AddTilesComponent/ProductSizeList'
import ProductTypeList from '../components/AddTilesComponent/ProductTypeList'
import ProductUseList from '../components/AddTilesComponent/ProductUseList'
import '../css/AddTiles.css'

const AddTilesScreen = (props) => {
  const [type, setType] = useState('')
  const [material, setMaterial] = useState('')
  const [use, setUse] = useState('')
  const [name, setName] = useState('')
  const [price, setPrice] = useState(0)
  const [tilePic, setTilePic] = useState(null)
  const [size, setSize] = useState('')
  const [finishing, setFinishing] = useState('')
  const [profileVisible, setProfileVisible] = useState(false)

  const [tileInfoSubmit, setTileInfoSubmit] = useState(false)
  const [tilePicSubmit, setTilePicSubmit] = useState(false)

  const TileAdd = useSelector((store) => store.TileAdd)
  const { response, loading, error } = TileAdd

  const TileImageUpload = useSelector((store) => store.TileImageUpload)
  const {
    loading: loading1,
    error: error1,
    response: response1,
  } = TileImageUpload

  const dispatch = useDispatch()

  const onSelectType = (value) => {
    console.log(value)
    setType(value)
    setProfileVisible(false)
  }

  const onSelectMaterial = (value) => {
    setMaterial(value)
    setProfileVisible(false)
  }

  const onSelectUse = (value) => {
    setUse(value)
    setProfileVisible(false)
  }

  const onSelectSize = (value) => {
    setSize(value)
    setProfileVisible(false)
  }

  const onSelectFinishing = (value) => {
    setFinishing(value)
    setProfileVisible(false)
  }

  const onAddTile = () => {
    let flag = 0
    if (flag === 0 && type.length === 0) {
      alert('please select product type')
      flag = 1
    }
    if (flag === 0 && material.length === 0) {
      alert('please select product material')
      flag = 1
    }
    if (flag === 0 && use.length === 0) {
      alert('please select product use')
      flag = 1
    }
    if (flag === 0 && size.length === 0) {
      alert('please select product size')
      flag = 1
    }
    if (flag === 0 && finishing.length === 0) {
      alert('please select product finishing')
      flag = 1
    }

    if (flag === 0 && tilePic == null) {
      alert('please select product image')
      flag = 1
    }

    if (flag === 0 && name.length === 0) {
      alert('please enter the name')
      flag = 1
    }

    if (flag === 0 && price === 0) {
      alert('please enter the price')
      flag = 1
    }
    if (flag === 0) {
      window.scrollTo(0, 0)
      setProfileVisible(true)
    }
  }

  const onFinalAdd = () => {
    setTileInfoSubmit(true)
    dispatch(TileAddFunc(name, material, type, use, size, finishing, price))
  }

  const uploadTilePic = (serialNo) => {
    console.log('in upload tile pic function')

    setTilePicSubmit(true)
    dispatch(tilePicUpload(tilePic, serialNo))
  }
  useEffect(() => {
    if (response && response.status === 'success' && tileInfoSubmit) {
      setTileInfoSubmit(false)
      uploadTilePic(response.data.serialNo)
    } else if (response && response.status === 'error' && tileInfoSubmit) {
      alert(response.data)
      setTileInfoSubmit(false)
    } else if (error && tileInfoSubmit) {
      alert(error)
      setTileInfoSubmit(false)
    }

    if (response1 && response1.status === 'success' && tilePicSubmit) {
      console.log(response1.data)
      setTilePicSubmit(false)
      alert('Tile added successfully')
    } else if (response1 && response1.status === 'error' && tilePicSubmit) {
      console.log(response1)
      alert(response1.data)
      setTilePicSubmit(false)
    } else if (error1 && tilePicSubmit) {
      alert(error1)
      setTilePicSubmit(false)
    }
  }, [response, loading, error, response1, loading1, error1])

  return (
    <div style={{ height: '1000px' }}>
      <div
        className="float-start"
        style={{ marginTop: '70px', marginLeft: '30px', width: '900px' }}>
        <h3 style={{ marginLeft: '40px' }}>Add Tile</h3>
        <div style={{ marginTop: '30px' }} className="form-group divAddtiles">
          <div style={{ width: '300px' }}>
            <label
              style={{ marginLeft: '35px', marginBottom: '5px' }}
              className="label1"
              htmlFor="Image">
              Tile pic
            </label>
            <input
              style={{ marginLeft: '35px', marginBottom: '5px' }}
              onChange={(e) => {
                setTilePic(e.target.files[0])
                setProfileVisible(false)
              }}
              type="file"
              id="Image"
              className="form-control"
              required
            />
          </div>
          <div style={{ marginLeft: '120px', marginTop: '-120px' }}>
            {tilePic != null && (
              <img
                className="imageAddTiles"
                style={{ marginTop: '10px' }}
                width="170px"
                height="170px"
                src={URL.createObjectURL(tilePic)}
              />
            )}
          </div>
        </div>
        <div
          style={{ marginTop: '10px', width: '600px' }}
          className="form-group">
          <label
            style={{ marginLeft: '35px', marginBottom: '5px' }}
            className="label1"
            htmlFor="name">
            Name
          </label>
          <input
            style={{ marginLeft: '30px', marginBottom: '25px' }}
            onChange={(e) => {
              setName(e.target.value)
              setProfileVisible(false)
            }}
            type="text"
            id="name"
            className="form-control"
            placeholder="enter the name of tiles"
            required
          />
        </div>
        <div
          style={{ marginTop: '10px', width: '600px' }}
          className="form-group">
          <label
            style={{ marginLeft: '35px', marginBottom: '5px' }}
            className="label1"
            htmlFor="price">
            Price
          </label>
          <input
            style={{ marginLeft: '30px', marginBottom: '25px' }}
            onChange={(e) => {
              setPrice(e.target.value)
              setProfileVisible(false)
            }}
            type="number"
            id="price"
            className="form-control"
            placeholder="enter the price of tiles"
            required
          />
        </div>
        <div>
          <ul className="ulAddTiles">
            <li>
              <ProductTypeList onSelectType={onSelectType} />
            </li>
            <li>
              <ProductMaterialList onSelectMaterial={onSelectMaterial} />
            </li>
            <li>
              <ProductUseList onSelectUse={onSelectUse} />
            </li>
          </ul>
        </div>
        <div>
          {type.length !== 0 && (
            <div style={{ marginTop: '100px', width: '600px' }}>
              <ul className="ulAddTiles1">
                <li>
                  <ProductSizeList type={type} onSelectSize={onSelectSize} />
                </li>
                <li className="float-end">
                  <ProductFinishingList
                    type={type}
                    onSelectFinishing={onSelectFinishing}
                  />
                </li>
              </ul>
            </div>
          )}
        </div>
        <div style={{ marginLeft: '280px', marginTop: '50px' }}>
          <button onClick={onAddTile} className="btn btn-outline-success">
            Add
          </button>
        </div>
      </div>
      {profileVisible && (
        <div className="infoDivAddTiles">
          {tilePic !== null && (
            <img
              width="250px"
              height="200px"
              src={URL.createObjectURL(tilePic)}
            />
          )}
          {name.length !== 0 && (
            <div
              style={{
                fontSize: '20px',
                fontWeight: 'bold',
                marginTop: '10px',
                textAlign: 'center',
              }}>
              {name}
            </div>
          )}
          {type.length !== 0 && (
            <div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  marginTop: '10px',
                  marginLeft: '10px',
                }}>
                type ::
              </span>{' '}
              {type}
            </div>
          )}
          {material.length !== 0 && (
            <div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  marginTop: '10px',
                  marginLeft: '10px',
                }}>
                material ::
              </span>{' '}
              {material}
            </div>
          )}
          {use.length !== 0 && (
            <div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  marginTop: '10px',
                  marginLeft: '10px',
                }}>
                use ::
              </span>{' '}
              {use}
            </div>
          )}
          {size.length !== 0 && (
            <div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  marginTop: '10px',
                  marginLeft: '10px',
                }}>
                size ::
              </span>{' '}
              {size}
            </div>
          )}
          {finishing.length !== 0 && (
            <div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  marginTop: '10px',
                  marginLeft: '10px',
                }}>
                finishing ::
              </span>{' '}
              {finishing}
            </div>
          )}
          {price !== 0 && (
            <div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  marginTop: '10px',
                  marginLeft: '10px',
                }}>
                price ::
              </span>{' '}
              {price}
            </div>
          )}
          <button
            onClick={onFinalAdd}
            style={{ marginLeft: '100px', marginTop: '20px' }}
            className="btn btn-outline-info">
            Add
          </button>
        </div>
      )}
    </div>
  )
}

export default AddTilesScreen
