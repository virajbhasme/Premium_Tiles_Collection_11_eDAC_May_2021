import { useState } from 'react'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useHistory } from 'react-router-dom'
import { profilePicUpload, signUp } from '../action/OwnerAction'
import SignUpInputs from '../components/SignUpComponents/SignIninputs'
import '../css/signup.css'
const SignUpScreen = (props) => {
  const [userInfoSubmit, setUserInfoSubmit] = useState(false)
  const [profilePicSubmit, setProfilePicSubmit] = useState(false)
  const [noRepeat, setNoRepeat] = useState(true)

  const OwnerSignUp = useSelector((store) => store.OwnerSignUp)
  const OwnerProfilePicupload = useSelector(
    (store) => store.OwnerProfilePicupload
  )

  const [profile, setProfile] = useState(null)
  const { response, loading, error } = OwnerSignUp
  const dispatch = useDispatch()
  const history = useHistory()

  const {
    loading: loading1,
    error: error1,
    response: response1,
  } = OwnerProfilePicupload

  const onRegister = (
    firstName,
    lastName,
    email,
    phone,
    pwd,
    birthDate,
    buildingName,
    colonyName,
    city,
    state,
    pincode,
    profilePic
  ) => {
    console.log('in register function ' + email)
    if (profilePic != null) {
      console.log(typeof profilePic)
      console.log('profile pic is available ')
      setProfile(profilePic)
    }
    setUserInfoSubmit(true)
    dispatch(
      signUp(
        firstName,
        lastName,
        email,
        phone,
        pwd,
        birthDate,
        buildingName,
        colonyName,
        city,
        state,
        pincode
      )
    )
  }

  const uploadProfilePic = (serialNo) => {
    console.log('in upload profile pic function')
    let val = false
    setNoRepeat(val)
    if (profile !== null) {
      console.log('profile is  type ' + typeof profile)

      setProfilePicSubmit(true)
      console.log('counter is ' + noRepeat)
      dispatch(profilePicUpload(profile, serialNo))
    }
  }

  useEffect(() => {
    if (response && response.status === 'success' && userInfoSubmit) {
      console.log(response)
      setUserInfoSubmit(false)
      if (profile === null) {
        alert('user register successfully now please signup')
        history.push('/signin')
      } else {
        if (response.data && noRepeat && profilePicSubmit === false) {
          let val = false
          setNoRepeat(val)
          uploadProfilePic(response.data.serialNo)
        }
      }
    } else if (response && response.status === 'error' && userInfoSubmit) {
      alert(response.data)
      setUserInfoSubmit(false)
    } else if (error && userInfoSubmit) {
      alert(error)
      setUserInfoSubmit(false)
    }

    if (response1 && response1.status === 'success' && profilePicSubmit) {
      console.log(response1.data)
      setProfilePicSubmit(false)
      alert('user register successfully now please signup')
      history.push('/signin')
    } else if (response1 && response1.status === 'error' && profilePicSubmit) {
      console.log(response1)
      setProfilePicSubmit(false)
      alert(response1.data)
      history.push('/signin')
    } else if (error1 && profilePicSubmit) {
      setProfilePicSubmit(false)
      alert(error1)
    }
  }, [response, loading, error, response1, loading1, error1])

  return (
    <div className="outer">
      <div className="box">
        <h3 style={{ textAlign: 'center' }}>SignUp</h3>
        <SignUpInputs signUp={onRegister} />
      </div>
    </div>
  )
}

export default SignUpScreen
