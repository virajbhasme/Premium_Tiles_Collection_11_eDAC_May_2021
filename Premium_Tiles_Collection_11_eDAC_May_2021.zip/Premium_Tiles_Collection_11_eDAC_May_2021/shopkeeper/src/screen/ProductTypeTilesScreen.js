import { useState } from 'react'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useLocation } from 'react-router-dom'
import { DeleteTileFunc, FetchTilesType } from '../action/TilesAction'
import TileModal from '../components/ProductsDisplayComponent/DisplayModal/TileModal'
import SearchByFinishing from '../components/ProductsDisplayComponent/SearchByFinishing'
import SearchByMaterial from '../components/ProductsDisplayComponent/SearchByMaterial'
import SearchBySize from '../components/ProductsDisplayComponent/SearchBySize'
import SearchByUse from '../components/ProductsDisplayComponent/SearchByUse'
import '../css/DisplayTIles.css'

const ProductTypeTilesScreen = (props) => {
  const [counter, setCounter] = useState(0)
  const [type, setType] = useState('')
  const [data, setData] = useState([])
  const [savedData, setSavedData] = useState([])
  const [size, setSize] = useState('')
  const [finishing, setFinishing] = useState('')
  const [use, setUse] = useState('')
  const [material, setMaterial] = useState('')
  const [fetchFilter, setFetchFilter] = useState(false)
  const [dataFetched, setDataFetched] = useState(false)
  const [tileDeleted, setTileDeleted] = useState(false)

  const location = useLocation()
  const dispatch = useDispatch()

  const TilesTypeFetch = useSelector((store) => store.TilesTypeFetch)
  const { response, loading, error } = TilesTypeFetch

  const TileDelete = useSelector((store) => store.TileDelete)
  const { loading: loading1, error: error1, response: response1 } = TileDelete

  const onLoad = () => {
    setCounter(1)
    console.log(location.state.value)
    setType(location.state.value)
    setDataFetched(true)
    dispatch(FetchTilesType(location.state.value))
  }

  const setDataValues = (values) => {
    let index = 0
    setData(
      values.map((tile) => {
        const byteCharacters = atob(tile.blob)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/*' })
        index++
        return {
          tile: tile.tiles,
          blob,
          index,
        }
      })
    )
    setSavedData(
       values.map((tile) => {
        const byteCharacters = atob(tile.blob)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/*' })
        index++
        return {
          tile: tile.tiles,
          blob,
          index,
        }
      })
    )
  }

  const convertSize = (value) => {
    let index = value.indexOf('X')
    let string1 = value.slice(1, index)
    let string2 = value.slice(index + 1)
    return string1 + ' X ' + string2 + ' cm'
  }

  const convertFinishing = (value) => {
    let index = value.indexOf(' ')
    if (index === -1) {
      return value.slice(0, 1) + value.slice(1).toLowerCase()
    } else {
      let result = value.slice(0, 1) + value.slice(1, index).toLowerCase() + ' '
      while (index !== -1) {
        let secondIndex = value.indexOf(' ', index + 1)
        if (secondIndex === -1) {
          result +=
            value.slice(index + 1, index + 2) +
            value.slice(index + 2).toLowerCase()
        } else {
          result +=
            value.slice(index + 1, index + 2) +
            value.slice(index + 2, secondIndex).toLowerCase() +
            ' '
        }
        index = secondIndex
      }
      return result
    }
  }

  const applyFilter = () => {
    let index = 0
    console.log(savedData)
    setData(
      savedData.filter((item) => {
        let flag = 0
        console.log('index ' + index)
        index++
        if (material.length !== 0) {
          console.log('material ' + material + ' ' + item.tile.productMaterial)
          if (item.tile.productMaterial !== material) {
            flag = 1
          }
        }

        if (use.length !== 0) {
          console.log('use' + use + ' ' + item.tile.productUse)
          if (item.tile.productUse !== use) {
            flag = 1
          }
        }

        if (size.length !== 0) {
          console.log('size' + size + ' ' + item.tile.productSize)
          if (item.tile.productSize !== size) {
            flag = 1
          }
        }

        if (finishing.length !== 0) {
          console.log(
            'finishing' + finishing + ' ' + item.tile.productFinishing
          )
          if (item.tile.productFinishing !== finishing) {
            flag = 1
          }
        }

        if (flag === 0) {
          return true
        } else {
          return false
        }
      })
    )
  }

  const onSelectMaterial = (value) => {
    if (value.indexOf(' ') !== -1) {
      console.log(
        (
          value.slice(0, value.indexOf(' ')) +
          value.slice(value.indexOf(' ') + 1)
        ).toUpperCase()
      )
      setMaterial(
        (
          value.slice(0, value.indexOf(' ')) +
          value.slice(value.indexOf(' ') + 1)
        ).toUpperCase()
      )
    } else {
      console.log(value.toUpperCase())
      setMaterial(value.toUpperCase())
    }
    setFetchFilter(true)
  }

  const onSelectUse = (value) => {
    console.log(value)
    if (value.indexOf(' ') !== -1) {
      console.log(
        (
          value.slice(0, value.indexOf(' ')) +
          value.slice(value.indexOf(' ') + 1)
        ).toUpperCase()
      )
      setUse(
        (
          value.slice(0, value.indexOf(' ')) +
          value.slice(value.indexOf(' ') + 1)
        ).toUpperCase()
      )
    } else {
      console.log(value.toUpperCase())
      setUse(value.toUpperCase())
    }
    setFetchFilter(true)
  }
  const onSelectSize = (value) => {
    console.log(value.toUpperCase())
    console.log(savedData)
    let stringVal =
      'S' +
      value.slice(0, value.indexOf(' ')) +
      'X' +
      value.slice(value.indexOf(' ') + 3, value.lastIndexOf(' '))

    console.log(stringVal)
    setSize(stringVal)
    setFetchFilter(true)
  }

  const onSelectFinishing = (value) => {
    console.log(value.toUpperCase())
    setFinishing(value.toUpperCase())
    setFetchFilter(true)
  }

  const onReset = () => {
    setData(
      savedData.map((m) => {
        return m
      })
    )
    setMaterial('')
    setSize('')
    setFinishing('')
    setUse('')
  }

  const onDeletePress = (serialNo) => {
    setTileDeleted(true)
    dispatch(DeleteTileFunc(serialNo))
  }

  useEffect(() => {
    if (counter === 0) {
      onLoad()
    }
    if (type !== location.state.value) {
      onLoad()
    }
    if (response && response.status === 'success' && dataFetched) {
      console.log(response)
      setDataFetched(false)
      setDataValues(response.data)
    } else if (response && response.status === 'error' && dataFetched) {
      alert(response.data)
    } else if (error) {
      alert(error)
    }
    if (response1 && response1.status === 'success' && tileDeleted) {
      console.log(response1.data)

      setTileDeleted(false)
      onLoad()
      alert('tile deleted successfully')
    } else if (response1 && response1.status === 'error' && tileDeleted) {
      console.log(response1)
      alert(response1.data)
      setTileDeleted(false)
    } else if (error1 && tileDeleted) {
      alert(error1)
      setTileDeleted(false)
    }

    if (fetchFilter) {
      applyFilter()
      setFetchFilter(false)
    }
  }, [
    location.state.value,
    response,
    loading,
    error,
    material,
    finishing,
    size,
    use,
    response1,
    loading1,
    error1,
  ])
  return (
    <div>
      <div
        style={{
          marginLeft: '50px',
          marginTop: '20px',
          marginBottom: '35px',
        }}>
        {location.state.value && (
          <span
            style={{
              fontSize: '26px',
              fontWeight: 'bold',
            }}>
            {location.state.value}
          </span>
        )}
        <span style={{ marginLeft: '700px' }}>
          {material.length !== 0 && (
            <span>
              {material} {'>>'}
            </span>
          )}
          {use.length !== 0 && (
            <span>
              {use} {'>>'}
            </span>
          )}
          {size.length !== 0 && (
            <span>
              {size} {'>>'}
            </span>
          )}
          {finishing.length !== 0 && <span>{finishing}</span>}
        </span>
        <span className="float-end" style={{ marginRight: '100px' }}>
          <button onClick={onReset} className=" btn btn-outline-dark">
            <i className="fas fa-undo"></i>
          </button>
        </span>
      </div>
      <div className="float-start productTypeRightDiv">
        <SearchByMaterial onSelectMaterial={onSelectMaterial} />

        <div style={{ marginTop: '50px' }}>
          <SearchByUse onSelectUse={onSelectUse} />
        </div>
        <div style={{ marginTop: '50px' }}>
          {type.length !== 0 && (
            <SearchBySize type={type} onSelectSize={onSelectSize} />
          )}
        </div>
        <div style={{ marginTop: '50px' }}>
          {type.length !== 0 && (
            <SearchByFinishing
              type={type}
              onSelectFinishing={onSelectFinishing}
            />
          )}
        </div>
      </div>

      <div>
        {data.length !== 0 ? (
          <div className="DisplayTilesClass">
            {data.map((tile) => {
              return (
                <li key={tile.index}>
                  <TileModal tile={tile} onDeletePress={onDeletePress} />
                  <div
                    style={{
                      fontSize: '16px',
                      marginTop: '10px',
                      marginLeft: '5px',
                    }}>
                    {tile.tile.tilesName}
                  </div>
                  <div
                    style={{
                      marginTop: '14px',
                      fontSize: '12px',
                      marginLeft: '5px',
                    }}>
                    <span>
                      {convertSize(tile.tile.productSize)} {' - '}
                    </span>
                    <span>{convertFinishing(tile.tile.productFinishing)}</span>
                  </div>
                </li>
              )
            })}
          </div>
        ) : (
          <div className="text-danger">products are not available</div>
        )}
      </div>
    </div>
  )
}

export default ProductTypeTilesScreen
