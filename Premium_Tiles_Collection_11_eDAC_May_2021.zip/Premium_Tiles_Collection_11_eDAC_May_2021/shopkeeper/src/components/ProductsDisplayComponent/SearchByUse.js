import { useState } from 'react'

const SearchByUse = (props) => {
  const [use] = useState([
    { index: 1, use: 'Bathroom' },
    { index: 2, use: 'Kitchen' },
    { index: 3, use: 'Outdoor' },
    { index: 4, use: 'Living Room' },
    { index: 5, use: 'Commercial Spaces' },
  ])

  const onDivSelect = (event) => {
    console.log(event.target.outerText)
    props.onSelectUse(event.target.outerText)
  }
  return (
    <div className="productTypeMaterialDiv">
      <div className="divLabel">Search By use</div>
      <div className="productTypeMaterialDivScroll">
        {use.map((use) => {
          return (
            <div
              key={use.index}
              className="divScroll"
              onClick={(event) => {
                onDivSelect(event)
              }}>
              {use.use}
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default SearchByUse
