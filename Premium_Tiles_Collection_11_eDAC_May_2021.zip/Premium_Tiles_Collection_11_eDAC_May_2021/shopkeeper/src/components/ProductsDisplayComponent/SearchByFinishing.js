import { useState } from 'react'

const SearchByFinishing = (props) => {
  const [finishingW] = useState([
    { index: 1, finishing: 'Polished' },
    { index: 2, finishing: 'Stone' },
    { index: 3, finishing: 'Marbletech' },
    { index: 4, finishing: 'Matt' },
    { index: 5, finishing: 'Premium Polished' },
    { index: 6, finishing: 'Super White' },
    { index: 7, finishing: 'Marbletech Crackling' },
    { index: 8, finishing: 'Premium Matt' },
    { index: 9, finishing: 'Punch' },
    { index: 10, finishing: 'Decor' },
    { index: 11, finishing: 'Wood' },
    { index: 12, finishing: 'Sugar' },
    { index: 13, finishing: 'Glossy Granula' },
    { index: 14, finishing: 'HD Polished' },
    { index: 15, finishing: 'Super Polished' },
    { index: 16, finishing: 'Gloss Matt' },
    { index: 17, finishing: 'Sugar Hone' },
    { index: 18, finishing: 'Carving' },
    { index: 19, finishing: 'Silky Satin' },
    { index: 20, finishing: 'HD High Gloss' },
    { index: 21, finishing: 'Satin Matt' },
    { index: 22, finishing: 'Matt Punch' },
    { index: 23, finishing: 'Super Matt' },
    { index: 24, finishing: 'Sparkle' },
    { index: 25, finishing: 'Glossy' },
    { index: 26, finishing: 'Rustic' },
    { index: 27, finishing: 'Satin' },
    { index: 28, finishing: 'Hard Matt' },
    { index: 29, finishing: 'Decor Sparkle' },
    { index: 30, finishing: 'Metalic' },
    { index: 31, finishing: 'Decor Polished' },
    { index: 32, finishing: 'Spanish Design' },
    { index: 33, finishing: 'Reactive' },
    { index: 34, finishing: 'Decor Matt' },
  ])

  const [finishingF] = useState([
    { index: 35, finishing: 'Polished Nanotech' },
    { index: 36, finishing: 'Marbletech' },
    { index: 37, finishing: 'Premium Marbletech' },
    { index: 38, finishing: 'Premium Polished' },
    { index: 39, finishing: 'Matt Diamond Shield' },
    { index: 40, finishing: 'Premium Matt' },
    { index: 41, finishing: 'Polished' },
    { index: 42, finishing: 'Premium Gloss Matt' },
    { index: 43, finishing: 'Gloss Matt' },
    { index: 44, finishing: 'Metal' },
    { index: 45, finishing: 'Metallic Streak' },
    { index: 46, finishing: 'Carving' },
    { index: 47, finishing: 'Premium Roto Matt' },
    { index: 48, finishing: 'Roto Matt Diamond Shield' },
    { index: 49, finishing: 'Stone' },
    { index: 50, finishing: 'Super White' },
    { index: 51, finishing: 'Matt' },
    { index: 52, finishing: 'MarbleTech Crackling' },
    { index: 53, finishing: 'Punch' },
    { index: 54, finishing: 'Wood' },
    { index: 55, finishing: 'Super Matt' },
    { index: 56, finishing: 'Decor' },
    { index: 57, finishing: 'Satin Matt' },
    { index: 58, finishing: 'Matt Punch' },
    { index: 59, finishing: 'Glossy Granula' },
    { index: 60, finishing: 'Super Polished' },
    { index: 61, finishing: 'HD Polished' },
    { index: 62, finishing: 'Sugar' },
    { index: 63, finishing: 'Silky Satin' },
    { index: 64, finishing: 'Gloss Matt' },
    { index: 65, finishing: 'Sugar Hone' },
    { index: 66, finishing: 'High Gloss' },
    { index: 67, finishing: 'HD High Gloss' },
    { index: 68, finishing: 'Lappato' },
    { index: 69, finishing: 'Hi-Gloss Polished' },
    { index: 70, finishing: 'Satin' },
    { index: 71, finishing: 'Crackling' },
    { index: 72, finishing: 'Sparkle' },
    { index: 73, finishing: 'Rustic' },
    { index: 74, finishing: 'Glossy' },
    { index: 75, finishing: 'Rock' },
    { index: 76, finishing: 'Slate' },
    { index: 77, finishing: 'Premium Matt-Punch' },
    { index: 78, finishing: 'Bookmatch' },
    { index: 79, finishing: 'Decor Sparkle' },
    { index: 80, finishing: 'Decor Matt' },
    { index: 81, finishing: 'Decor Polished' },
    { index: 82, finishing: 'Hard Matt' },
  ])

  const onDivSelect = (event) => {
    console.log(event.target.outerText)
    props.onSelectFinishing(event.target.outerText)
  }

  return (
    <div className="productTypeMaterialDiv">
      <div className="divLabel">Search By Finishing</div>
      <div className="productTypeMaterialDivScroll">
        {props.type &&
          props.type === 'Wall' &&
          finishingW.map((finishing) => {
            return (
              <div
                key={finishing.index}
                className="divScroll"
                onClick={(event) => {
                  onDivSelect(event)
                }}>
                {finishing.finishing}
              </div>
            )
          })}
        {props.type &&
          props.type === 'Floor' &&
          finishingF.map((finishing) => {
            return (
              <div
                key={finishing.index}
                className="divScroll"
                onClick={(event) => {
                  onDivSelect(event)
                }}>
                {finishing.finishing}
              </div>
            )
          })}
      </div>
    </div>
  )
}

export default SearchByFinishing
