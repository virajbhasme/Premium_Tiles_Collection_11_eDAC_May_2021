import { Dropdown, DropdownButton } from 'react-bootstrap'

const ProductUseList = (props) => {
  const onDropDownSelect = (event) => {
    console.log('hello')
    console.log(event.target.outerText)
    props.onSelectUse(event.target.outerText)
  }
  return (
    <DropdownButton
      id="dropdown-variants-secondary"
      variant="secondary"
      title="Product Use">
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Bathroom
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Living Room
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Kitchen
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Outdoor
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Commercial Spaces
      </Dropdown.Item>
    </DropdownButton>
  )
}

export default ProductUseList
