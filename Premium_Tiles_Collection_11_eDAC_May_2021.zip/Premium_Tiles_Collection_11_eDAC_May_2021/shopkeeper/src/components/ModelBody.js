import { useEffect } from 'react'

const ModalBody = (props) => {
  useEffect(() => {
    console.log(props.profilePic)
  })
  return (
    <div>
      {props.profilePic && (
        <img
          width="100px"
          height="100px"
          src={URL.createObjectURL(props.profilePic)}
        />
      )}
      {props.userInfo.firstName && props.userInfo.lastName && (
        <div>
          name : {props.userInfo.firstName} {props.userInfo.lastName}
        </div>
      )}
      {props.userInfo.phone && <div>phone : {props.userInfo.phone}</div>}
      {props.userInfo.email && <div>email : {props.userInfo.email}</div>}
      {props.userInfo.addr.buildingName && props.userInfo.addr.colonyName && (
        <div>
          address : {props.userInfo.addr.buildingName},
          {props.userInfo.addr.colonyName},{props.userInfo.addr.city},
          {props.userInfo.addr.state},{props.userInfo.addr.pincode}
        </div>
      )}
    </div>
  )
}

export default ModalBody
