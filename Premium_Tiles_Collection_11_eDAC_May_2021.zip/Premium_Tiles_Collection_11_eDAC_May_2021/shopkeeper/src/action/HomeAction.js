import axios from 'axios'
import {
  HOME_PRODUCT_FETCH_FAIL,
  HOME_PRODUCT_FETCH_REQUEST,
  HOME_PRODUCT_FETCH_SUCCESS,
} from '../constants/HomeConstants'

export const HomeProductFetchFunc = () => {
  return (dispatch) => {
    dispatch({
      type: HOME_PRODUCT_FETCH_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/home/get_products'

    axios
      .get(url)
      .then((response) => {
        dispatch({
          type: HOME_PRODUCT_FETCH_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: HOME_PRODUCT_FETCH_FAIL,
          payload: error,
        })
      })
  }
}
