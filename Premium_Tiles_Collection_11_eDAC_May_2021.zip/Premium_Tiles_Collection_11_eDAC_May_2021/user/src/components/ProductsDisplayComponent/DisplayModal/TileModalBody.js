const TileModalBody = (props) => {
  return (
    <div>
      {props.tile && (
        <img
          width="200px"
          height="200px"
          src={URL.createObjectURL(props.tile.blob)}
        />
      )}
      {props.tile && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Type ::{' '}
          </span>{' '}
          {props.tile.tile.productType}
        </div>
      )}
      {props.tile && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Material ::{' '}
          </span>{' '}
          {props.tile.tile.productMaterial}
        </div>
      )}
      {props.tile && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Base ::{' '}
          </span>{' '}
          {props.tile.tile.productBase}
        </div>
      )}
      {props.tile && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Size ::{' '}
          </span>{' '}
          {props.tile.tile.productSize}
        </div>
      )}

      {props.tile && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Finishing ::{' '}
          </span>{' '}
          {props.tile.tile.productFinishing}
        </div>
      )}
       {props.tile && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Price ::{' '}
          </span>{' '}
          {props.tile.tile.price}
        </div>
      )}
    </div>
  )
}

export default TileModalBody
