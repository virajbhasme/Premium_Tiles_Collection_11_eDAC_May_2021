import { useState } from 'react'
import { Modal } from 'react-bootstrap'
import CartTileModalBody from './CartTileModalBody'

const CartTileModal = (props) => {
  const [show, setShow] = useState(false)

  const handleClose = () => setShow(false)
  const handleShow = () => {
    console.log(props.cart)
    setShow(true)
  }

  return (
    <>
      {props.cart && (
        <img
          onClick={handleShow}
          className="DisplayTilesImageClassCart"
          src={URL.createObjectURL(props.cart.blob)}
        />
      )}

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          {props.cart && (
            <Modal.Title>{props.cart.cart.tile.tilesName}</Modal.Title>
          )}
        </Modal.Header>
        <Modal.Body>
          {props.cart && <CartTileModalBody cart={props.cart} />}
        </Modal.Body>
        <Modal.Footer>
          <button className="btn btn-outline-secondary" onClick={handleClose}>
            Close
          </button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default CartTileModal
