import { useEffect, useState } from 'react'
import { NavDropdown } from 'react-bootstrap'
import { useSelector } from 'react-redux'

import { useHistory } from 'react-router-dom'
import Example from './Example'

import '../css/header.css'

const Header = (props) => {
  const [counter, setCounter] = useState(0)
  const OwnerSignIn = useSelector((store) => store.OwnerSignIn)

  const { loading, error, response } = OwnerSignIn
  const history = useHistory()

  const goToTiles = () => {
    history.push('/add-tile')
  }

  const goToHome = () => {
    history.push('/home')
  }

  const ProductTypeSelect = (value) => {
    console.log('value is ' + value)
    const myData = {
      value,
    }
    history.push('/product-type', myData)
  }

  const BeforeProductTypeSelect = (value) => {
    console.log('value is ' + value)
    const myData = {
      value,
    }
    history.push('/before-product-type', myData)
  }

  const ProductMaterialSelect = (value) => {
    console.log('value is ' + value)
    const myData = {
      value,
    }
    history.push('/product-material', myData)
  }

  const BeforeProductMaterialSelect = (value) => {
    console.log('value is ' + value)
    const myData = {
      value,
    }
    history.push('/before-product-material', myData)
  }

  const goToCart = () => {
    history.push('/cart')
  }

  const goToAboutUs = () => {
    history.push('/about-us')
  }

  const onLogin = () => {
    history.push('/signin')
  }

  useEffect(() => {
    console.log(window.location.pathname)
    console.log(counter)
    let num = counter + 1
    setCounter(num)
  }, [window.location.pathname, loading, error, response])

  if (
    window.location.pathname === '/signin' ||
    window.location.pathname === '/signup' ||
    window.location.pathname === '/forget-password'
  ) {
    return null
  }

  return (
    <div>
      {sessionStorage.getItem('id') ? (
        <nav className="navbar navbar-expand-lg navbar-light bg-light ">
          <div className="container-fluid">
            <button className="navbar-brand btn btn-light" onClick={goToHome}>
              Premium Tiles Collection
            </button>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li style={{ marginLeft: '50px' }} className="nav-item ">
                  <NavDropdown
                    title="Products"
                    id="basic-nav-dropdown"
                    active="true">
                    <NavDropdown.Item
                      onClick={() => {
                        ProductTypeSelect('Wall')
                      }}>
                      Wall Tiles
                    </NavDropdown.Item>
                    <NavDropdown.Item
                      onClick={() => {
                        ProductTypeSelect('Floor')
                      }}>
                      Floor Tiles
                    </NavDropdown.Item>
                  </NavDropdown>
                </li>
                <li style={{ marginLeft: '50px' }} className="nav-item">
                  <NavDropdown
                    title="Material"
                    id="basic-nav-dropdown"
                    active="true">
                    <NavDropdown.Item
                      onClick={() => {
                        ProductMaterialSelect('Glazed Vitrified')
                      }}>
                      Glazed Vitrified Tiles
                    </NavDropdown.Item>
                    <NavDropdown.Item
                      onClick={() => {
                        ProductMaterialSelect('Ceramic')
                      }}>
                      Ceramic Tiles
                    </NavDropdown.Item>
                    <NavDropdown.Item
                      onClick={() => {
                        ProductMaterialSelect('Polished Vitrified')
                      }}>
                      Polished Vitrified Tiles
                    </NavDropdown.Item>
                  </NavDropdown>
                </li>
                <li style={{ marginLeft: '50px' }} className="nav-item">
                  <button
                    onClick={goToTiles}
                    className="nav-link active btn btn-light"
                    aria-current="page">
                    Request Custom Tiles
                  </button>
                </li>
                <li style={{ marginLeft: '50px' }} className="nav-item">
                  <button
                    onClick={goToAboutUs}
                    className="nav-link active btn btn-light"
                    aria-current="page">
                    About us
                  </button>
                </li>
              </ul>
            </div>

            <span className="float-end headerList">
              <ul>
                <li>
                  <span onClick={goToCart}>
                    <i class="fas fa-shopping-cart"></i>
                  </span>
                </li>
                <li>
                  <Example />
                </li>
              </ul>
            </span>
          </div>
        </nav>
      ) : (
        <nav className="navbar navbar-expand-lg navbar-light bg-light ">
          <div className="container-fluid">
            <button className="navbar-brand btn btn-light" onClick={goToHome}>
              Premium Tiles Collection
            </button>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li style={{ marginLeft: '50px' }} className="nav-item ">
                  <NavDropdown
                    title="Products"
                    id="basic-nav-dropdown"
                    active="true">
                    <NavDropdown.Item
                      onClick={() => {
                        BeforeProductTypeSelect('Wall')
                      }}>
                      Wall Tiles
                    </NavDropdown.Item>
                    <NavDropdown.Item
                      onClick={() => {
                        BeforeProductTypeSelect('Floor')
                      }}>
                      Floor Tiles
                    </NavDropdown.Item>
                  </NavDropdown>
                </li>
                <li style={{ marginLeft: '50px' }} className="nav-item">
                  <NavDropdown
                    title="Material"
                    id="basic-nav-dropdown"
                    active="true">
                    <NavDropdown.Item
                      onClick={() => {
                        BeforeProductMaterialSelect('Glazed Vitrified')
                      }}>
                      Glazed Vitrified Tiles
                    </NavDropdown.Item>
                    <NavDropdown.Item
                      onClick={() => {
                        BeforeProductMaterialSelect('Ceramic')
                      }}>
                      Ceramic Tiles
                    </NavDropdown.Item>
                    <NavDropdown.Item
                      onClick={() => {
                        BeforeProductMaterialSelect('Polished Vitrified')
                      }}>
                      Polished Vitrified Tiles
                    </NavDropdown.Item>
                  </NavDropdown>
                </li>

                <li style={{ marginLeft: '50px' }} className="nav-item">
                  <button
                    onClick={goToAboutUs}
                    className="nav-link active btn btn-light"
                    aria-current="page">
                    About us
                  </button>
                </li>
              </ul>
            </div>

            <span className="float-end headerList">
              <ul>
                <li>
                  <button
                    onClick={onLogin}
                    className="nav-link text-light  btn btn-dark">
                    Login
                  </button>
                </li>
              </ul>
            </span>
          </div>
        </nav>
      )}
    </div>
  )
}

export default Header
