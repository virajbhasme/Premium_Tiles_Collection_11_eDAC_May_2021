import {
  CART_ADD_FAIL,
  CART_ADD_REQUEST,
  CART_ADD_SUCCESS,
  CART_FETCH_FAIL,
  CART_FETCH_REQUEST,
  CART_FETCH_SUCCESS,
  CART_ITEM_INCREASE_FAIL,
  CART_ITEM_INCREASE_REQUEST,
  CART_ITEM_INCREASE_SUCCESS,
  CART_ITEM_REDUCE_FAIL,
  CART_ITEM_REDUCE_REQUEST,
  CART_ITEM_REDUCE_SUCCESS,
  CART_ORDER_FAIL,
  CART_ORDER_REQUEST,
  CART_ORDER_SUCCESS,
} from '../constants/CartConstants'

export const CartAddReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_ADD_REQUEST:
      return { loading: true }
    case CART_ADD_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_ADD_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const CartFetchReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_FETCH_REQUEST:
      return { loading: true }
    case CART_FETCH_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_FETCH_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const CartItemReduceReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_ITEM_REDUCE_REQUEST:
      return { loading: true }
    case CART_ITEM_REDUCE_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_ITEM_REDUCE_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const CartItemIncreaseReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_ITEM_INCREASE_REQUEST:
      return { loading: true }
    case CART_ITEM_INCREASE_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_ITEM_INCREASE_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const CartOrderReducer = (state = {}, action) => {
  switch (action.type) {
    case CART_ORDER_REQUEST:
      return { loading: true }
    case CART_ORDER_SUCCESS:
      return { loading: false, response: action.payload }
    case CART_ORDER_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}
