const AboutUsScreen = (props) => {
  return ( 
    <div className="bg-dark">
    <div className="container">
    <h1 align="center" style={{ color: 'white'}}>About us</h1>
        <div className="row h-1 align-items-center">
            <div className="row align-items-center mb-5">
                <div className="col-lg- order-2 order-lg-1">
                    <i className="fa fa-bar-chart fa-2x mb-3 text-primary"></i>
                    <br />
                    <h2 className="font-weight-bold mt-5 mb-4">
                        <centre>
                            <i style={{ color: 'white', float: 'left' }}>Company Information</i>
                        </centre>
                    </h2><br /><br />
                    <hr style={{ color: 'white'}} />
                    <p className="font-italic text-white">
                      Premium Tiles Collection's manufacturing units are equipped with cutting edge modern technology.Intense automation, robotic car application and a zero chance for human error arefew reasons for Premium Tiles Collection to be the number 1 in the industry.Founded 7 years ago, 
                      Premium Tiles Collection has since then grown stronger with its hard work, innovations and patronage 
                      from our discerning customers.
                      The Indian consumer's rapidly growing appetite for style and aesthetics is the 
                      inspiration behind every design of Tiles and its pace to keep up with the customer 
                      and market demands has made Premium Tiles Collection a synonym for quality, service and innovation - 
                      not only in the domestic market but in the international market too.
                    </p>
                    <br />
                    <hr style={{ color: 'white'}} />

                    <b style={{ fontSize: '20px', fontFamily: 'monospace', color: 'white' }}>Corporate Office</b>
                    <br />
                    <br />
                    <span style={{ color: 'silver' }}>
                        Due to COVID, all our display centers have restricted entry for the customers, considering the safety measures.
                        Kindly take an appointment prior to your visit.
                    </span>
                    <br />
                    <br />
                    <h2 style={{ fontweight: 'bold', marginbottom: '5px', paddingtop: '10px', color: 'orange', fontsize: '10px', lineheight: '1.5' }} > Premium Tiles Collection</h2>
                    <p className="font-italic text-light mb-4">
                        {" "}
                        <br />
                        J1/B1 (Extn.), Mohan Co - op Industrial Estate
                        <br />
                        (Opp. Badarpur Thermal Power Station),
                        <br />
                        JM Road, Pune, Maharashtra - 411 044
                        <br />
                        Phone: +91-11-2694 6409
                        <br />
                        Fax: +91-11-2694 6407, 2694 9544
                        <br />
                        Email: info@premiumtilescollection.com
                    </p>
                    <hr style={{ color: 'white'}} />
                    <br /><br /><br /><br />
                    <br />
                </div>
            </div>
        </div>
    </div>
</div>
  )
}

export default AboutUsScreen
