import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import { useHistory } from 'react-router'
import { CartFetchFunc, CartItemIncreaseFunc } from '../action/CartAction'
import CartTileModal from '../components/CartTilesComponent/DisplayModal/CartTileModal'
import '../css/cart.css'

const CartScreen = (props) => {
  const [counter, setCounter] = useState(true)
  const [data, setData] = useState([])
  const [dataFetched, setDataFetched] = useState(false)
  const [cartAmount, setCartAmount] = useState(0)
  const [amountArr, setAmountArr] = useState([])
  const [amountChanging, setAmountChanging] = useState(false)

  const [total, setTotal] = useState(0)

  const CartFetch = useSelector((store) => store.CartFetch)
  const { response, loading, error } = CartFetch

  const CartItemIncrease = useSelector((store) => store.CartItemIncrease)
  const {
    loading: loading1,
    error: error1,
    response: response1,
  } = CartItemIncrease

  const dispatch = useDispatch()

  const history = useHistory()

  const onLoad = () => {
    setDataFetched(true)
    dispatch(CartFetchFunc())
  }
  const setDataValues = (values) => {
    let index = 0
    setTotal(0)
    let sum = 0
    setData(
      values.map((cart) => {
        const byteCharacters = atob(cart.blob)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/*' })
        index++
        sum = sum + cart.cart.tile.price * cart.cart.count
        return {
          cart: cart.cart,
          blob,
          index,
        }
      })
    )

    setAmountArr(
      values.map((cart) => {
        return {
          count: cart.cart.count,
        }
      })
    )

    setTotal(sum)
  }

  const convertSize = (value) => {
    let index = value.indexOf('X')
    let string1 = value.slice(1, index)
    let string2 = value.slice(index + 1)
    return string1 + ' X ' + string2 + ' cm'
  }

  const convertFinishing = (value) => {
    let index = value.indexOf(' ')
    if (index === -1) {
      return value.slice(0, 1) + value.slice(1).toLowerCase()
    } else {
      let result = value.slice(0, 1) + value.slice(1, index).toLowerCase() + ' '
      while (index !== -1) {
        let secondIndex = value.indexOf(' ', index + 1)
        if (secondIndex === -1) {
          result +=
            value.slice(index + 1, index + 2) +
            value.slice(index + 2).toLowerCase()
        } else {
          result +=
            value.slice(index + 1, index + 2) +
            value.slice(index + 2, secondIndex).toLowerCase() +
            ' '
        }
        index = secondIndex
      }
      return result
    }
  }

  const amountChange = (value, index) => {
    index--
    console.log(value + ' ' + index)
    amountArr[index].count = value
  }

  const cartAddFunc = (id, index) => {
    index--
    console.log(cartAmount + ' ' + id)
    let cart = data.filter((cart) => {
      if (cart.cart.id === id) {
        console.log(cart)
        return cart
      }
    })

    console.log('original amount is ' + amountArr[index].count)
    if (
      window.confirm(
        'are u sure u want to add ' +
          amountArr[index].count +
          ' of tile ' +
          cart[0].cart.tile.tilesName
      )
    ) {
      setAmountChanging(true)
      dispatch(CartItemIncreaseFunc(id, amountArr[index].count))
    }
  }

  const onOrderPress = () => {
    let value = total
    const myData = {
      value,
    }
    history.push('/order-product', myData)
  }
  useEffect(() => {
    if (counter) {
      setCounter(false)
      onLoad()
    }

    if (response && response.status === 'success' && dataFetched) {
      console.log(response.data)
      setDataFetched(false)
      setDataValues(response.data)
    } else if (response && response.status === 'error' && dataFetched) {
      alert(response.data)
    } else if (error) {
      alert(error)
    }

    if (response1 && response1.status === 'success' && amountChanging) {
      setAmountChanging(false)
      console.log(response1.data)
      onLoad()
      alert(response1.data)
    } else if (response1 && response1.status === 'error' && amountChanging) {
      console.log(response1)
      setAmountChanging(false)
      alert(response1.data)
    } else if (error1 && amountChanging) {
      setAmountChanging(false)
      alert(error1)
    }
  }, [response, loading, error, response1, loading1, error1])
  return (
    <div>
      <div
        style={{ marginTop: '10px', marginBottom: '60px', marginLeft: '20px' }}>
        <span style={{ fontSize: '18px', fontWeight: 'bold' }}>Cart </span>
        <span className="float-end" style={{ marginRight: '50px' }}>
          <span style={{ marginRight: '40px' }}> total price :: {total}</span>
          <button onClick={onOrderPress} className="btn btn-outline-dark">
            order
          </button>
        </span>
      </div>

      <div>
        {data.length !== 0 ? (
          <div className="DisplayTilesClassCart">
            {data.map((cart) => {
              return (
                <li key={cart.index}>
                  <CartTileModal cart={cart} />
                  <div
                    style={{
                      fontSize: '16px',
                      marginTop: '10px',
                      marginLeft: '5px',
                    }}>
                    {cart.cart.tile.tilesName}
                  </div>
                  <div
                    style={{
                      marginTop: '14px',
                      fontSize: '12px',
                      marginLeft: '5px',
                    }}>
                    <span>
                      {convertSize(cart.cart.tile.productSize)} {' - '}
                    </span>
                    <span>
                      {convertFinishing(cart.cart.tile.productFinishing)}
                    </span>
                  </div>

                  <div style={{ marginTop: '10px', marginLeft: '5px' }}>
                    <span style={{ fontSize: '12px', fontWeight: 'bold' }}>
                      {' '}
                      Qty ::{' '}
                    </span>{' '}
                    <span>
                      <input
                        onChange={(e) => {
                          amountChange(e.target.value, cart.index)
                        }}
                        style={{ width: '100px' }}
                        type="number"
                        defaultValue={cart.cart.count}
                      />
                    </span>
                    <span>
                      <button
                        onClick={() => {
                          cartAddFunc(cart.cart.id, cart.index)
                        }}
                        style={{ marginLeft: '60px', marginBottom: '10px' }}
                        className="btn btn-sm btn-dark">
                        add
                      </button>
                    </span>
                  </div>
                </li>
              )
            })}
          </div>
        ) : (
          <div className="text-danger">products are not available</div>
        )}
      </div>
    </div>
  )
}

export default CartScreen
