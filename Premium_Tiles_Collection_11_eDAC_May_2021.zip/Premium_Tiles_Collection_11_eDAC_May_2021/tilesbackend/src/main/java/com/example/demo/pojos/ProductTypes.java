package com.example.demo.pojos;

public enum ProductTypes {
WALL,FLOOR
}
