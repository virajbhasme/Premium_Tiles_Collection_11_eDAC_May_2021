package com.example.demo.utils;


import java.util.ArrayList;
import java.util.List;

public  class ProductUtils {
	public static List<String> GetProductSizeForWall(){
      List<String> list1=new ArrayList<String>() ;
      String[] sizes={
    	  "S80X120","S60X120","S40X120","S40X80","S30X60","S30X45","S15X60","S15X45","S30X20"
		};
		for (String string : sizes) {
			list1.add(string);
		}
		return list1;
	}
	
	public static List<String> GetProductFinishingForWall(){
	      List<String> list1=new ArrayList<String>() ;
	      String[] finishing={
	    		  "POLISHED","STONE","MARBLETECH","MATT","PREMIUM POLISHED","SUPER WHITE","MARBLETECH CRACKLING","PREMIUM MATT","PUNCH","DECOR","WOOD","SUGAR","GLOSSY GRANULA",
	    		  "HD POLISHED","SUPER POLISHED","GLOSS MATT","SUGAR HONE","CARVING","SILKY SATIN","HD HIGH GLOSS","SATIN MATT","MATT PUNCH","SUPER MATT","SPARKLE","GLOSSY",
	    		  "RUSTIC","SATIN","HARD MATT","DECOR SPARKLE","METALIC","DECOR POLISHED","SPANISH DESIGN","REACTIVE","DECORMATT"
			};
			for (String string : finishing) {
				list1.add(string);
			}
			return list1;
		}
	
	public static List<String> GetProductSizeForFloor(){
	      List<String> list1=new ArrayList<String>() ;
	      String[] sizes={
	    	  "S100X200","S120X180","S29X180","S120X120","S80X160","S80X120","S60X120","S20X120","S100X100","S80X80",
	    	  "S40X80","S13X80","S60X60","S30X60","S15X60","S40X40","S30X30"
			};
			for (String string : sizes) {
				list1.add(string);
			}
			return list1;
		}
		
		public static List<String> GetProductFinishingForFloor(){
		      List<String> list1=new ArrayList<String>() ;
		      String[] finishing={
		    		"POLISHED NANOTECH","MARBLETECH","PREMIUM MARBLETECH","PREMIUM POLISHED","MATT DIAMOND SHIELD",
		    		"PREMIUM MATT","POLISHED","PREMIUM GLOSS MATT","METAL","METALLIC STREAK","CARVING","PREMIUM ROTO MATT",
		    		"ROTO MATT DIAMOND SHIELD","STONE","SUPER WHITE","MATT","MARBLETECH CRACKLING","PUNCH","WOOD","SUPER MATT",
		    		"MATT PUNCH","GLOSSY GRANULA","SUPER POLISHED","HD POLISHED","SUGAR","SILKY SATIN","GLOSS MATT","SUGAR HOME",
		    		"HIGH GLOSS","HD HIGH GLOSS","LAPPATO","HI-GLOSS POLISHED","SATIN","CRACKLING","SPARKLE","RUSTIC","GLOSSY",
		    		"ROCK","SLATE","PREMIUM MATT-PUNCH","BOOKMATCH","DECOR SPARKLE","DECOR MATT","DECOR POLISHED","HARD MATT"		
				};
				for (String string : finishing) {
					list1.add(string);
				}
				return list1;
			}
		
		public static String calculateStringSize(String s) {
			int index=s.indexOf(' ');
			int secondIndex,thirdIndex;
			secondIndex=index+3;
			thirdIndex=s.indexOf(' ', secondIndex);
			int num1=Integer.parseInt(s.substring(0, index));
			int num2=Integer.parseInt(s.substring(secondIndex, thirdIndex));
			return "S"+num1+"X"+num2;
			
		}
		
		
}
