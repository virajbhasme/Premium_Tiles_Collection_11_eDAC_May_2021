package com.example.demo.dto;

public class OtherDto {
private int id;
private int amount;

public OtherDto(int id) {
	super();
	this.id = id;
}


public OtherDto(int id, int amount) {
	super();
	this.id = id;
	this.amount = amount;
}


public OtherDto() {
	super();
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}



public int getAmount() {
	return amount;
}


public void setAmount(int amount) {
	this.amount = amount;
}


@Override
public String toString() {
	return "OtherDto [id=" + id + ", amount=" + amount + "]";
}





}
