package com.example.demo.service;

import java.util.UUID;

import com.example.demo.pojos.User;



public interface IUserService {
	User addUser(User u);
	User getUserByEmail(String email);
	User updatepwd(String email,String pwd);
	User getUserBySerialNo(UUID serialNo);
	User getUserByEmailAndPwd(String email,String pwd);
    User uploadPhoto(UUID id,String fileName);
    User updateProfile(User u,UUID serialNo);
    User updateUser(User u);
}