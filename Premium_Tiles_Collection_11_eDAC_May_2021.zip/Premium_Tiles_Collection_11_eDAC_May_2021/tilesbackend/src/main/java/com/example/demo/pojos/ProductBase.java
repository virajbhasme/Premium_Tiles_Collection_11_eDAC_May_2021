package com.example.demo.pojos;

public enum ProductBase {
ORIGINAL,CUSTOMIZED
}
