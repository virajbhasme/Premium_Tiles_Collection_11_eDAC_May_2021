package com.example.demo.dao;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojos.User;



public interface UserRepository extends JpaRepository<User,Integer> {
	Optional<User> findByEmail(String email);
	Optional<User> findByEmailAndPwd(String email,String pwd);
	Optional<User> findByEmailAndSerialNo(String email,UUID serialNo);
	Optional<User> findBySerialNo(UUID serialNo);
}
