package com.example.demo.dto;


import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import org.springframework.web.multipart.MultipartFile;

import com.example.demo.pojos.Material;
import com.example.demo.pojos.ProductBase;
import com.example.demo.pojos.ProductTypes;
import com.example.demo.pojos.ProductUse;

public class TileDto {
	private String tilesName;
	
	
	private  String productBase;
	
	private  String productType;

	private  String productUse;

	private String productSize;
	
	private String productFinishing;
	private String productMaterial;
	
	private double price;
	
	public TileDto(String tilesName, String productBase, String productType, String productUse, String productSize,
			String productFinishing, String productMaterial, double price) {
		super();
		System.out.println("in ctor of TileDto");
		this.tilesName = tilesName;
		this.productBase = productBase;
		this.productType = productType;
		this.productUse = productUse;
		this.productSize = productSize;
		this.productFinishing = productFinishing;
		this.productMaterial = productMaterial;
		this.price = price;
	}
	public TileDto() {
		super();
		System.out.println("in ctor of TileDto");
	}
	public String getTilesName() {
		return tilesName;
	}
	public void setTilesName(String tilesName) {
		this.tilesName = tilesName;
	}
	public String getProductBase() {
		return productBase;
	}
	public void setProductBase(String productBase) {
		this.productBase = productBase;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductUse() {
		return productUse;
	}
	public void setProductUse(String productUse) {
		this.productUse = productUse;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public String getProductFinishing() {
		return productFinishing;
	}
	public void setProductFinishing(String productFinishing) {
		this.productFinishing = productFinishing;
	}
	public String getProductMaterial() {
		return productMaterial;
	}
	public void setProductMaterial(String productMaterial) {
		this.productMaterial = productMaterial;
	}
	
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "TileDto [tilesName=" + tilesName + ", productBase=" + productBase + ", productType=" + productType
				+ ", productUse=" + productUse + ", productSize=" + productSize + ", productFinishing="
				+ productFinishing + ", productMaterial=" + productMaterial + ", price=" + price + "]";
	}
	
	
	
	
	
}
