package com.example.demo.controller.shop;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Cart_Result_Data_dto;
import com.example.demo.dto.OtherDto;
import com.example.demo.dto.ResultDto;
import com.example.demo.dto.UUIDS_dto;
import com.example.demo.pojos.Cart;
import com.example.demo.pojos.User;
import com.example.demo.service.CartServiceImpl;
import com.example.demo.utils.UserUtils;

@RestController
@CrossOrigin("http://localhost:3070")
@RequestMapping("/shop-keeper/cart")
public class ShopKeeperCartController {
@Autowired
private CartServiceImpl cartServiceImpl;

String location = "D:\\premium tiles collection edac project\\Images\\Tiles";

public ShopKeeperCartController() {
	System.out.println("in ctor of ShopKeeperCartController");
}
@GetMapping("/get-orders")
public ResponseEntity<?> getOrders() {
	System.out.println("in getOrders func of ShopKeeperCartController" );
	ResultDto result = new ResultDto("error", "something went wrong");
	try {
		List<Cart> carts=cartServiceImpl.getByOrder();
		if(carts==null) {
			result.setData("no order available");
		}else {
			List<Cart_Result_Data_dto> resultData = new ArrayList<Cart_Result_Data_dto>();
			for (Cart cart : carts) {
				Blob blob = UserUtils.GetImage(location, cart.getTile().getTilesImage(), "user_dummy.png");
				if (blob != null) {
					resultData.add(new Cart_Result_Data_dto(cart, blob));
				}

			}
			result.setStatus("success");
			result.setData(resultData);

		}
		
	} catch (Exception e) {
		result.setData(e.getMessage());
		System.out.println("exception caught in getOrders function of ShopKeeperCartController");
		System.out.println(e.getMessage());
	}
	return ResponseEntity.ok(result);

}
@GetMapping("/get-pending-request")
public ResponseEntity<?> getPendingRequest() {
	System.out.println("in getPendingRequest func of ShopKeeperCartController");
	ResultDto result = new ResultDto("error", "something went wrong");
	try {
		List<Cart> carts=cartServiceImpl.getByIsCustomizedAndAceepted();
		if(carts==null) {
			result.setData("no order available");
		}else {
			System.out.println("cart count is "+carts.size());
			List<Cart_Result_Data_dto> resultData = new ArrayList<Cart_Result_Data_dto>();
			for (Cart cart : carts) {
				
				Blob blob = UserUtils.GetImage(location, cart.getTile().getTilesImage(), "user_dummy.png");
				if (blob != null) {
					resultData.add(new Cart_Result_Data_dto(cart, blob));
				}

			}
			result.setStatus("success");
			result.setData(resultData);

		}
		
	} catch (Exception e) {
		result.setData(e.getMessage());
		System.out.println("exception caught in getPendingRequest function of ShopKeeperCartController");
		System.out.println(e.getMessage());
	}
	return ResponseEntity.ok(result);

}


@PostMapping("/deliver-product")
public ResponseEntity<?> deliverProduct(@RequestBody OtherDto id) {
	System.out.println("in deliverProduct func of ShopKeeperCartController");
	System.out.println(id.getId());
	ResultDto result = new ResultDto("error", "something went wrong");
	try {
		Cart cart=cartServiceImpl.getCartByCartId(id.getId());
		cart.setDelivered(true);
		Cart c=cartServiceImpl.AddCartProduct(cart);
		if(c!=null) {
			result.setStatus("success");
			result.setData("product delivered successfully");
		}
		
	} catch (Exception e) {
		result.setData(e.getMessage());
		System.out.println("exception caught in deliverProduct function of ShopKeeperCartController");
		System.out.println(e.getMessage());
	}
	return ResponseEntity.ok(result);

}

@PostMapping("/accept-product")
public ResponseEntity<?> AcceptProduct(@RequestBody OtherDto id) {
	System.out.println("in AcceptProduct func of ShopKeeperCartController");
	System.out.println(id.getId());
	ResultDto result = new ResultDto("error", "something went wrong");
	try {
		Cart cart=cartServiceImpl.getCartByCartId(id.getId());
	  cart.setAccepted(true);
	  cart.getTile().setPrice(1000);
		Cart c=cartServiceImpl.AddCartProduct(cart);
		if(c!=null) {
			result.setStatus("success");
			result.setData("product accepted successfully");
		}
		
	} catch (Exception e) {
		result.setData(e.getMessage());
		System.out.println("exception caught in AcceptProduct function of ShopKeeperCartController");
		System.out.println(e.getMessage());
	}
	return ResponseEntity.ok(result);

}


}
