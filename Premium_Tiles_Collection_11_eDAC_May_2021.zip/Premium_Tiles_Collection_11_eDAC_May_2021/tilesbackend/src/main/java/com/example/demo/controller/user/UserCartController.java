package com.example.demo.controller.user;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Cart_Result_Data_dto;
import com.example.demo.dto.OtherDto;
import com.example.demo.dto.ResultDto;
import com.example.demo.dto.TileDto;
import com.example.demo.dto.Tiles_Result_Data_dto;
import com.example.demo.dto.UUIDS_dto;
import com.example.demo.pojos.Cart;
import com.example.demo.pojos.Material;
import com.example.demo.pojos.ProductBase;
import com.example.demo.pojos.ProductTypes;
import com.example.demo.pojos.ProductUse;
import com.example.demo.pojos.Tiles;
import com.example.demo.pojos.User;
import com.example.demo.service.CartServiceImpl;
import com.example.demo.service.ProductServiceImpl;
import com.example.demo.service.UserServiceImpl;
import com.example.demo.utils.ProductUtils;
import com.example.demo.utils.UserUtils;

@RestController
@CrossOrigin("http://localhost:3080")
@RequestMapping("/user/cart")
public class UserCartController {

	@Autowired
	private ProductServiceImpl productServiceImpl;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private CartServiceImpl cartServiceImpl;

	String location = "D:\\premium tiles collection edac project\\Images\\Tiles";

	public UserCartController() {
		System.out.println("in ctor of userCartController");
	}

	@PostMapping("/add-cart")
	public ResponseEntity<?> AddToCart(@RequestBody UUIDS_dto uuids) {
		System.out.println("in AddToCart func of UserCartController" + uuids.getuSerialNo());
		System.out.println("product serial no " + uuids.getpSerialNo());
		ResultDto result = new ResultDto("error", "something went wrong");
		try {
			User u = userServiceImpl.getUserBySerialNo(uuids.getuSerialNo());
			if (u != null) {
				int flag = 0;
				if (u.getCarts().size() != 0) {
					for (Cart cart : u.getCarts()) {
						System.out.println(cart.toString());
						if (cart.getTile().getSerialNo().compareTo(uuids.getpSerialNo()) == 0
								&& cart.isOrdered() == false) {
							flag = 1;
							cart.setCount(cart.getCount() + 1);
							break;
						}
					}
				}

				if (flag == 0) {
					System.out.println("");
					Cart c = new Cart();
					c.setCount(c.getCount() + 1);
					Tiles t = productServiceImpl.getBySerialNo(uuids.getpSerialNo());
					if (t != null) {
						c.setUser(u);
						c.setTile(t);
						c = cartServiceImpl.AddCartProduct(c);
						if (c != null) {
							System.out.println("cart added successfully");
							result.setStatus("success");
							result.setData("added to cart successfully");
						} else {
							result.setData("something went wrong while adding to cart");
						}
					} else {
						result.setData("tile not found");
					}
				} else {
					u = userServiceImpl.updateUser(u);
					if (u != null) {
						System.out.println(" user cart added successfully");
						result.setStatus("success");
						result.setData("added to cart successfully");
					} else {
						result.setData("something went wrong while updating");
					}

				}
			} else {
				result.setData("user not found");
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception caught in addcart function of cartcontroller");
			System.out.println(e.getMessage());
		}

		return ResponseEntity.ok(result);
	}

	@PutMapping("/get-carts")
	public ResponseEntity<?> getCartProduct(@RequestBody UUIDS_dto uuids) {
		System.out.println("in getCartProduct func of UserCartController" + uuids.getuSerialNo());
		ResultDto result = new ResultDto("error", "something went wrong");
		try {
			User u = userServiceImpl.getUserBySerialNo(uuids.getuSerialNo());
			List<Cart> carts = u.getCarts();
			if (carts.isEmpty()) {
				result.setStatus("list is empty");
			} else {
				List<Cart_Result_Data_dto> resultData = new ArrayList<Cart_Result_Data_dto>();

				for (Cart cart : carts) {
					if (cart.isCustomized() == true && cart.isAccepted() == true && cart.isOrdered() == false
							|| cart.isCustomized() == false && cart.isAccepted() == false
									&& cart.isOrdered() == false) {
						Blob blob = UserUtils.GetImage(location, cart.getTile().getTilesImage(), "user_dummy.png");
						if (blob != null) {
							resultData.add(new Cart_Result_Data_dto(cart, blob));
						}
					}

				}

				result.setData(resultData);
				result.setStatus("success");
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception caught in getCartProduct function of cartcontroller");
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);

	}

	@PutMapping("/reduce-quantity")
	public ResponseEntity<?> reduceQuantityOfCart(@RequestBody OtherDto id) {
		System.out.println("in reduceQuantityOfCart func of UserCartController" + id);
		ResultDto result = new ResultDto("error", "something went wrong");
		try {
			Cart cart = cartServiceImpl.getCartByCartId(id.getId());
			if (cart != null) {
				if (cart.getCount() == 1) {
					cartServiceImpl.DeleteCart(id.getId());
					result.setStatus("success");
					result.setData("item deleted successfully");
				} else {
					cart.setCount(cart.getCount() - 1);
					Cart c = cartServiceImpl.AddCartProduct(cart);
					if (c != null) {
						result.setData("item reduced successdully");
						result.setStatus("success");
					} else {
						result.setData("something went wrong while updating cart");
					}
				}
			} else {
				result.setData("cart is not found");
			}

		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception caught in reduceQuantityOfCart function of cartcontroller");
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);

	}

	@PutMapping("/increase-quantity")
	public ResponseEntity<?> increaseQuantityOfCart(@RequestBody OtherDto id) {
		System.out.println("in increaseQuantityOfCart func of UserCartController" + id);
		ResultDto result = new ResultDto("error", "something went wrong");
		try {
			if(id.getAmount()!=0) {
				Cart cart = cartServiceImpl.getCartByCartId(id.getId());
				if (cart != null) {
					cart.setCount(id.getAmount());
					Cart c = cartServiceImpl.AddCartProduct(cart);
					if (c != null) {
						result.setData("item added successdully");
						result.setStatus("success");
					} else {
						result.setData("something went wrong while updating cart");
					}
				} else {
					result.setData("cart is not found");
				}
			}else {
				cartServiceImpl.DeleteCart(id.getId());
				result.setStatus("success");
				result.setData("cart deleted successfully");
			}

		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception caught in increaseQuantityOfCart function of cartcontroller");
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);

	}

	@PutMapping("/order-product")
	public ResponseEntity<?> orderProductOfCart(@RequestBody UUIDS_dto id) {
		System.out.println("in increaseQuantityOfCart func of UserCartController" + id);
		ResultDto result = new ResultDto("error", "something went wrong");
		try {
			User u = userServiceImpl.getUserBySerialNo(id.getuSerialNo());
			if (u != null) {
				int count = cartServiceImpl.OrderCartUserFunc(u);
				if (count != 0) {
					result.setStatus("success");
					result.setData(count + " products ordered successfully");
				} else {
					result.setData("while ordering something went wrong");
				}
			} else {
				result.setData("user not found");
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception caught in increaseQuantityOfCart function of cartcontroller");
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);

	}
	

	@PostMapping("/add-custom-Product")
	public ResponseEntity<?> addCustomTile(@RequestHeader UUID id,@RequestBody TileDto tile){
		System.out.println("in addCustomTile func of userCartController");
		System.out.println(tile.toString());
		ResultDto result=new ResultDto("error","something went wrong");
		Tiles tileName=productServiceImpl.getByTilesName(tile.getTilesName());
		if(tileName==null) {
			if(tile.getTilesName()!=null && tile.getProductFinishing()!=null & tile.getProductMaterial() !=null && 
					tile.getProductSize() != null && tile.getProductType()!=null && tile.getProductUse() != null ) {
				ProductTypes type=ProductTypes.valueOf(tile.getProductType().toUpperCase());
				String useOfTIle=tile.getProductUse().replaceAll("\\s", "");
				String mat=tile.getProductMaterial().replaceAll("\\s", "");
				Material material=Material.valueOf(mat.toUpperCase());
				ProductUse use=ProductUse.valueOf(useOfTIle.toUpperCase());
				ProductBase base=ProductBase.ORIGINAL;
				String sizeS=" ",sizeF=" ";
				if(tile.getProductType().compareToIgnoreCase("Wall")==0) {
				    String s=ProductUtils.calculateStringSize(tile.getProductSize());
				   if( ProductUtils.GetProductSizeForWall().contains(s)) {
					   sizeS=s;
				   }
				   
				   if(ProductUtils.GetProductFinishingForWall().contains(tile.getProductFinishing().toUpperCase())) {
					   sizeF=tile.getProductFinishing().toUpperCase();
				   }
				   
				
				   
				}else {
					 String s=ProductUtils.calculateStringSize(tile.getProductSize());
					   if( ProductUtils.GetProductSizeForFloor().contains(s)) {
						   sizeS=s;
					   }
					   
					   if(ProductUtils.GetProductFinishingForFloor().contains(tile.getProductFinishing().toUpperCase())) {
						   sizeF=tile.getProductFinishing().toUpperCase();
					   }
				}
				
				
				if(!sizeS.isBlank() && !sizeF.isBlank()) {
					Tiles t=new Tiles(tile.getTilesName(), null, base, type, use, sizeS, sizeF, material);
					t.setProductBase(ProductBase.CUSTOMIZED);
					System.out.println(t.toString());
					Tiles tiles=productServiceImpl.addCustomizedTile(t,id);
					if(tiles!=null) {
						System.out.println("register tile is "+tiles.toString());
						Tiles tile1=productServiceImpl.getByTilesName(t.getTilesName());
						System.out.println("searched tile is "+tile1.toString());
						User u=userServiceImpl.getUserBySerialNo(id);
						if(u!=null) {
							System.out.println("user is "+u);
							Cart c=new Cart();
							c.setCount(c.getCount()+1);
							c.setCustomized(true);
							c.setTile(tiles);
							c.setUser(u);
						c=cartServiceImpl.AddCartProduct(c);
						if(c!=null) {
							result.setData(tiles);
							result.setStatus("success");
						}else {
							result.setData("while adding cart something went wrong");
						}
							
						}else {
							result.setData("while finding user something went wrong");
						}
						
					}else {
						result.setData("while adding tile something went wrong");
					}
					
				}else {
					if(sizeS.isBlank()) {
						result.setData("please enter the valid size");
					}else {
						result.setData("please enter the valid finishing");
					}
				}
				
			}else {
				if(tile.getTilesName() == null) {
					result.setData("please give tile name");
				}else if (tile.getProductUse() == null) {
					result.setData("please give product use");
				}else if(tile.getProductType() == null) {
					result.setData("please give product type");
				}else if(tile.getProductMaterial() == null) {
					result.setData("please give product material");
				}else if(tile.getProductSize() == null) {
					
					result.setData("please give product size");
				}else if(tile.getProductFinishing() == null) {
					result.setData("please give product finishing");
				}
			}
		}else {
			result.setData("tile name already given please pick another one");
		}
		return ResponseEntity.ok(result);
	}
	

}
