package com.example.demo.service;

import java.util.List;
import java.util.UUID;

import com.example.demo.pojos.Material;
import com.example.demo.pojos.ProductTypes;
import com.example.demo.pojos.Tiles;

public interface IProductService {
Tiles addTile(Tiles t);
Tiles addCustomizedTile(Tiles t,UUID id);
Tiles getBySerialNo(UUID id);
Tiles uploadPhoto(UUID id,String image);
List<Tiles> GetTilesByType(ProductTypes type);
List<Tiles> GetTilesByMaterial(Material mat);
Tiles getByTilesName(String name);
long deleteTilesBySerialNo(UUID id);
List<Tiles> fetchLatestTiles();
}
