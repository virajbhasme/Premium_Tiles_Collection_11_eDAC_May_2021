package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CartRepository;
import com.example.demo.pojos.Cart;
import com.example.demo.pojos.User;

@Service
@Transactional
public class CartServiceImpl implements ICartService {

	@Autowired
	private CartRepository cartRepository;

	public CartServiceImpl() {
		System.out.println("in ctor of CartServiceImpl");
	}

	@Override
	public List<Cart> GetByUser(User u) {
		System.out.println("in function GetByUser of " + getClass().getName() + " " + u.getFirstName());
		try {

			Optional<List<Cart>> optional = cartRepository.findByUserAndIsOrdered(u, false);
			if (optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in GetByUser CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Cart AddCartProduct(Cart c) {
		System.out.println("in function AddCartProduct of " + getClass().getName() + " " + c.getUser().getFirstName());
		try {
			return cartRepository.save(c);
		} catch (Exception e) {
			System.out.println("exception caught in AddCartProduct CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Cart getCartByCartId(int id) {
		System.out.println("in function getCartByCartId of " + getClass().getName() + " " + id);
		try {
			Optional<Cart> optional = cartRepository.findById(id);
			if (optional.isPresent()) {
				return optional.get();
			}

		} catch (Exception e) {
			System.out.println("exception caught in getCartByCartId CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public void DeleteCart(int id) {

		System.out.println("in function DeleteCart of " + getClass().getName() + " " + id);
		try {
			cartRepository.deleteById(id);

		} catch (Exception e) {
			System.out.println("exception caught in getCartByCartId CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return;
	}

	@Override
	public int OrderCartUserFunc(User u) {
		System.out.println("in function OrderCartUserFunc of " + getClass().getName() + " " + u.getFirstName());
		try {

			Optional<List<Cart>> optional = cartRepository.findByUserAndIsOrdered(u, false);
			if (optional.isPresent()) {
				int count = 0;
				List<Cart> carts = optional.get();
				for (Cart cart : carts) {
					if(cart.isCustomized()==true&&cart.isAccepted()==true||cart.isCustomized()==false&&cart.isAccepted()==false) {
						cart.setOrdered(true);
						count++;
						cartRepository.save(cart);
					}

				}

				return count;
			}
		} catch (Exception e) {
			System.out.println("exception caught in OrderCartUserFunc CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public List<Cart> getByOrder() {
		System.out.println("in function getByOrder of " + getClass().getName());
		try {
			Optional<List<Cart>>optional=cartRepository.finByisOrderedAndisDelivered(true,false);
			if(optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in getByOrder CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public List<Cart> getByIsCustomizedAndAceepted() {
		System.out.println("in function getByIsCustomizedAndAceepted of " + getClass().getName());
		try {
			Optional<List<Cart>>optional=cartRepository.findByisCustomizedAndisAccepted(true,false);
			if(optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in getByIsCustomizedAndAceepted CartServiceImpl");
			System.out.println(e.getMessage());
		}
		return null;
	}

}
