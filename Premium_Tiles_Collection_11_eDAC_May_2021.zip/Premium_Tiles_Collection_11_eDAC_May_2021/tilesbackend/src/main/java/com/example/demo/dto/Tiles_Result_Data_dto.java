package com.example.demo.dto;

import java.sql.Blob;

import com.example.demo.pojos.Tiles;

public class Tiles_Result_Data_dto {
private Tiles tiles;
private Blob blob;
public Tiles_Result_Data_dto(Tiles tiles, Blob blob) {
	super();
	System.out.println("in ctor of Tiles_Result_Data_dto");
	this.tiles = tiles;
	this.blob = blob;
}
public Tiles_Result_Data_dto() {
	super();
	System.out.println("in ctor of Tiles_Result_Data_dto");
}
public Tiles getTiles() {
	return tiles;
}
public void setTiles(Tiles tiles) {
	this.tiles = tiles;
}
public Blob getBlob() {
	return blob;
}
public void setBlob(Blob blob) {
	this.blob = blob;
}


}
