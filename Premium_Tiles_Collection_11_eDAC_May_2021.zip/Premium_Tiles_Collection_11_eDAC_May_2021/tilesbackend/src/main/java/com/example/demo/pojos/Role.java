package com.example.demo.pojos;

public enum Role {
	SHOPKEEPER,USER
}

