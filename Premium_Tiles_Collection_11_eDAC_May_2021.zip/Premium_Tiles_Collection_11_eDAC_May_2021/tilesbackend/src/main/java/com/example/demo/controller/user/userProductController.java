package com.example.demo.controller.user;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.Email_UUID_dto;
import com.example.demo.dto.ResultDto;
import com.example.demo.dto.TileDto;
import com.example.demo.dto.Tiles_Result_Data_dto;
import com.example.demo.pojos.Material;
import com.example.demo.pojos.ProductBase;
import com.example.demo.pojos.ProductTypes;
import com.example.demo.pojos.ProductUse;
import com.example.demo.pojos.Tiles;
import com.example.demo.service.ProductServiceImpl;
import com.example.demo.service.UserServiceImpl;
import com.example.demo.utils.ProductUtils;
import com.example.demo.utils.UserUtils;

@RestController
@CrossOrigin("http://localhost:3080")
@RequestMapping("/user/product")
public class userProductController {
	String location ="D:\\premium tiles collection edac project\\Images\\Tiles";
	@Autowired
private ProductServiceImpl productServiceImpl;
	
	public userProductController() {
		System.out.println("in ctor of ProductController");
		
	}
	

	@PostMapping("/image-upload")
	public ResponseEntity<?> imageUpload(@RequestHeader UUID id, @RequestBody MultipartFile file) throws Exception {

		System.out.println("in image uploading function of " + getClass().getName());
		ResultDto result=new ResultDto("error","something went wrong while uploading image");
		try {
			System.out.println("file name "+file.getOriginalFilename());
			String fileName=file.getOriginalFilename();
			Path path = Paths.get(location, file.getOriginalFilename());
			
			File temp=new File(path.toString());
			System.out.println(temp.exists());
			while(temp.exists() ) {
				String name=file.getOriginalFilename();
				int index=name.indexOf('.');
				int max=10000,min=99999;
				int b = (int)(Math.random()*(max-min+1)+min);  
				int c = (int)(Math.random()*(max-min+1)+min);  
				 fileName=name.substring(0,index)+b+c+name.substring(index);
				 System.out.println("filename "+fileName);
				path = Paths.get(location, fileName);
				temp=new File(path.toString());
			}
			Tiles t=productServiceImpl.uploadPhoto(id, fileName);
		
			if(t!=null) {
				file.transferTo(new File(location, t.getTilesImage()));
				result.setData("image uploaded successfully");
				result.setStatus("success");
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in imageUpload  of "+getClass().getName());
			System.out.println(e.getLocalizedMessage());
		}
		return ResponseEntity.ok(result);
	}
	
	
	@PutMapping("/image-download")
	public ResponseEntity<?> imageDownload(@RequestBody Email_UUID_dto email_UUID_dto) throws Exception {
		ResultDto result=new ResultDto("error","something went wrong");
		System.out.println("in image downloading function of " +getClass().getName()+" "+email_UUID_dto.getEmail());
		try {
			Tiles t = productServiceImpl.getBySerialNo(email_UUID_dto.getSerialNo());
			if (t != null ) {
				Path  path;
			if(t.getTilesImage()!=null) {
				path = Paths.get(location, t.getTilesImage());
				File temp=new File(path.toString());
				if(temp.exists()) {
					path = Paths.get(location, t.getTilesImage());
					
				}else {
					 path = Paths.get(location, "user_dummy.png");
				}
			}else {
				 path = Paths.get(location, "user_dummy.png");
			}
				
				InputStreamResource input = new InputStreamResource(new FileInputStream(path.toFile()));
				ClassPathResource imageFile = new ClassPathResource(path.toString());
				byte[] imageBytes = org.springframework.util.StreamUtils.copyToByteArray(input.getInputStream());
				Blob blob = new SerialBlob(imageBytes);
				HttpHeaders headers = new HttpHeaders();
				headers.add("content-type", Files.probeContentType(path));
				return ResponseEntity.ok().header(HttpHeaders.CONTENT_TYPE, "image/*").body(blob);
			}else {
				result.setData("error:wrong librarian id");
			}
		} catch (Exception e) {
			result.setData("error:"+e.getMessage());
			System.out.println("exception in imageDownload  of "+getClass().getName());
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}


	@PutMapping("/get-type")
	public ResponseEntity<?> GetTilesByProductType(@RequestBody Email_UUID_dto type){
		ResultDto result=new ResultDto("error","something went wrong");
		System.out.println("in GetTilesByProductType function of " +getClass().getName()+" "+type.getEmail());
		try {
			ProductTypes pType=ProductTypes.valueOf(type.getEmail().toUpperCase());
		    List<Tiles> tiles=productServiceImpl.GetTilesByType(pType);
		    if(tiles != null) {
		    	List<Tiles_Result_Data_dto> resultData=new ArrayList<Tiles_Result_Data_dto>();
		    	for (Tiles tiles2 : tiles) {
		    		if(tiles2.getProductBase() == ProductBase.ORIGINAL) {
		    			Blob blob=UserUtils.GetImage(location, tiles2.getTilesImage(),"user_dummy.png");
						if(blob!=null) {
							resultData.add(new Tiles_Result_Data_dto(tiles2,blob));
						}
		    		}
				}

		    	result.setStatus("success");
		    	result.setData(resultData);
		    }
		    
		} catch (Exception e) {
			result.setData("error:"+e.getMessage());
			System.out.println("exception in GetTilesByProductType  of "+getClass().getName());
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}
	
	@PutMapping("/get-material")
	public ResponseEntity<?> GetTilesByProductMaterial(@RequestBody Email_UUID_dto type){
		ResultDto result=new ResultDto("error","something went wrong");
		System.out.println("in GetTilesByProductMaterial function of " +getClass().getName()+" "+type.getEmail());
		try {
			String mat=type.getEmail().replaceAll("\\s", "");
			Material material=Material.valueOf(mat.toUpperCase());
		    List<Tiles> tiles=productServiceImpl.GetTilesByMaterial(material);
		    if(tiles != null) {
		    	List<Tiles_Result_Data_dto> resultData=new ArrayList<Tiles_Result_Data_dto>();
		    	for (Tiles tiles2 : tiles) {
		    		
		    		if(tiles2.getProductBase() == ProductBase.ORIGINAL) {
		    			Blob blob=UserUtils.GetImage(location, tiles2.getTilesImage(),"user_dummy.png");
						if(blob!=null) {
							resultData.add(new Tiles_Result_Data_dto(tiles2,blob));
						}
		    		}
				}

		    	result.setStatus("success");
		    	result.setData(resultData);
		    }
		    
		} catch (Exception e) {
			result.setData("error:"+e.getMessage());
			System.out.println("exception in GetTilesByProductMaterial  of "+getClass().getName());
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}
	
	
	@PutMapping("/delete-custom-tile")
	public ResponseEntity<?> DeleteCustomTile(@RequestBody Email_UUID_dto type){
		ResultDto result=new ResultDto("error","something went wrong");
		System.out.println("in DeleteCustomTile function of " +getClass().getName()+" "+type.getSerialNo());
		try {
			
		    long res=productServiceImpl.deleteTilesBySerialNo(type.getSerialNo());
		    if(res != 0) {
		    	result.setData("tile deleted successfully");
		    	result.setStatus("success");
		    }
		} catch (Exception e) {
			result.setData("error:"+e.getMessage());
			System.out.println("exception in DeleteTile  of "+getClass().getName());
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}
	
	
}
