package com.example.demo.service;

import java.util.List;

import com.example.demo.pojos.Cart;
import com.example.demo.pojos.User;

public interface ICartService {
	Cart AddCartProduct(Cart c);
List<Cart> GetByUser(User u);
Cart getCartByCartId(int id);
void DeleteCart(int id);
int OrderCartUserFunc(User u);
List<Cart> getByOrder();
List<Cart> getByIsCustomizedAndAceepted();
}
